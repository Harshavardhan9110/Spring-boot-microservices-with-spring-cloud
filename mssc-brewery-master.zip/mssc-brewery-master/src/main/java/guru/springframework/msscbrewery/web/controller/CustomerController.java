package guru.springframework.msscbrewery.web.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import guru.springframework.msscbrewery.services.CustomerService;
import guru.springframework.msscbrewery.web.model.CustomerDto;

@RestController
@RequestMapping("/api/v1/customer")
public class CustomerController {
	
	@Autowired
	private final CustomerService customerServisec;
	
	public CustomerController(CustomerService customerServisec) {
		this.customerServisec=customerServisec;
	}

	@GetMapping({"/{customerId}"})
	public ResponseEntity<CustomerDto> getCustomerDtls(@PathVariable("customerId")int customerId){
		return new ResponseEntity<>(customerServisec.getCustomerById(customerId),HttpStatus.OK);
	}
}
