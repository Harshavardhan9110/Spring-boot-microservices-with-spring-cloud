package guru.springframework.msscbrewery.services;

import java.util.UUID;

import org.springframework.stereotype.Service;

import guru.springframework.msscbrewery.web.model.CustomerDto;
@Service
public class CustomerServiceImpl implements CustomerService{

	@Override
	public CustomerDto getCustomerById(int CustomerId) {
		// TODO Auto-generated method stub
		return CustomerDto.builder()
				.Id(1)
				.name("Harsha").build();
	}

}
